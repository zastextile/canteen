<?php
// ===== ZAS Canteen configuration (matches uploads/database.sql) =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'zfpvkgkjhr');
define('DB_USER', 'zfpvkgkjhr');
define('DB_PASS', '2MjxWHfVFy');

define('APP_NAME', 'Canteen');
define('APP_URL',  'https://canteen.thqlinen.com/');
define('CURRENCY', 'PKR');

// Optional: OpenAI key for Urdu voice on the Sales screen. '' = phone's built-in voice (free).
define('OPENAI_API_KEY', '');
define('TTS_MODEL', 'gpt-4o-mini-tts');
define('TTS_VOICE', 'alloy');
define('VOICE_DIR', __DIR__ . '/voices');
define('UPLOAD_DIR', __DIR__ . '/uploads');

date_default_timezone_set('Asia/Karachi');
